import os


def run():
    print("[*] In environment module.")
    return str(os.environ)
