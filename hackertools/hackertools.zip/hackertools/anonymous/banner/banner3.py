import os
cmd = 'clear'
os.system(cmd)
from colorama import Fore, Back, Style

details="""
________________________________________
|author:   |iyanuhacks                  |
|__________|____________________________|
|github:   |https://github.com/iyanuhacks
|__________|____________________________|
|Facebook: |iyanu hacks                 |
|__________|____________________________|
|whatsapp: |+2347040435646              |
|__________|____________________________|
|website:  |www.iyanuhacks.com          |
|__________|____________________________|

"""
print(Back.BLUE + details)


banner="""
 _    ,                             _   
' )  /         /         _/_       //   
 /--/ __.  _. /_  _  __  /  __ __ // _  
/  (_(_/|_(__/ <_</_/ (_<__(_)(_)</_/_)_
                                        
                                        
"""
print(Back.BLUE + banner)
