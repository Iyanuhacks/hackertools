from .core import *

__name__ = "findweb"
__version__ = "2.3.12"
__author__ = "iyanu hacks"
__github__ = "https://github.com/iyanuhacks"
__all__ = ["findweb", "__name__", "__version__", "__author__","__github__",]

