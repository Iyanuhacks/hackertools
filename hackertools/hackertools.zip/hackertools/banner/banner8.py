import os
cmd = 'clear'
os.system(cmd)
import colorama
banner="""
    )                                           
 ( /(             )             )         (     
 )\())   )     ( /(   (  (   ( /(         )\    
((_)\ ( /(  (  )\()) ))\ )(  )\())(    ( ((_|   
 _((_))(_)) )\((_)\ /((_|()\(_))/ )\   )\ _ )\  
| || ((_)_ ((_) |(_|_))  ((_) |_ ((_) ((_) ((_) 
| __ / _` / _|| / // -_)| '_|  _/ _ \/ _ \ (_-< 
|_||_\__,_\__||_\_\\___||_|  \__\___/\___/_/__/ 
                                                
"""
from colorama import Fore, Back, Style

details="""
________________________________________
|author:   |iyanuhacks                  |
|__________|____________________________|
|github:   |https://github.com/iyanuhacks
|__________|____________________________|
|Facebook: |iyanu hacks                 |
|__________|____________________________|
|whatsapp: |+2347040435646              |
|__________|____________________________|
|website:  |www.iyanuhacks.com          |
|__________|____________________________|

"""
print(Fore.YELLOW + details)

print(Style.BRIGHT +banner)
#hackertools by iyanuhacks
#thanks for using this tool
