import os
cmd = 'clear'
os.system(cmd)
from colorama import Fore, Back, Style

details="""
________________________________________
|author:   |iyanuhacks                  |
|__________|____________________________|
|github:   |https://github.com/iyanuhacks
|__________|____________________________|
|Facebook: |iyanu hacks                 |
|__________|____________________________|
|whatsapp: |+2347040435646              |
|__________|____________________________|
|website:  |www.iyanuhacks.com          |
|__________|____________________________|

"""
print(Back.YELLOW + details)

print(Style.DIM +"[̲̅H̲̅][̲̅a̲̅][̲̅c̲̅][̲̅k̲̅][̲̅e̲̅][̲̅r̲̅][̲̅t̲̅][̲̅o̲̅][̲̅o̲̅][̲̅l̲̅][̲̅s̲̅]")

#hackertools by iyanuhacks
#thanks for using this tool
