import os
cmd = 'clear'
os.system(cmd)
from colorama import Fore, Back, Style
banner1=""" ____________
( iyanuhacks )
 ------------
    o
     o
"""
banner0="""
.  .      .         ,       .   
|__| _. _.;_/ _ ._.-+- _  _ | __
|  |(_](_.| \(/,[   | (_)(_)|_) 
                                """
details="""
________________________________________
|author:   |iyanuhacks                  |
|__________|____________________________|
|github:   |https://github.com/iyanuhacks
|__________|____________________________|
|Facebook: |iyanu hacks                 |
|__________|____________________________|
|whatsapp: |+2347040435646              |
|__________|____________________________|
|website:  |www.iyanuhacks.com          |
|__________|____________________________|

"""
print(Fore.RED + banner1)
print(Fore.GREEN + banner0)
print(Fore.YELLOW + details)


#hackertools by iyanuhacks
#thanks for using this tool
