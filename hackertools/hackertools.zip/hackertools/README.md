# hackertools
* this is script is expected to be use for educational purposes of only,am less concerned about the damage caused by the misusement of this script
* this script is an all in one script for both newbies and masters in hacking,it is fully coded in python 3
* although this script is still under construction but we expect you to update it first before you use it so as to enjoy new features added to it
* """ hackertools by iyanuhacks """
* greetings to :
* anonymous hack
* Joel greyhat
* anongrey hat procracker
* joy hacks
* Momo Fishman
* and others
