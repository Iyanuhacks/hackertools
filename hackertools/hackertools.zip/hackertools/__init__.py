"""hackertools
  _  _         _           _            _
 | || |__ _ __| |_____ _ _| |_ ___  ___| >
 | __ / _` / _| / / -_) '_|  _/ _ \/ _ \ >
 |_||_\__,_\__|_\_\___|_|  \__\___/\___/_>
   
A tool for both grey and ethical hackers to test their knowledge on hacking and cybersecurity field
it also you support all hacking tools required by a hacker to completea task
the tools have many modules and library to work with
this script is coded by iyanuhacks
and render as a gift to a beloved friends
"""
__all__ = ['','modules']
__version__ = '1.0'
__github__ = 'https://github.com/iyanuhacks/hackertools.git'

def main():
    for module in __all__:
        exec("import {}".format(module))
#hackertools by iyanuhacks
#thanks for using this tool
